<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package mynameisgregg
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<?php if(is_page('send-to-gregg') || is_page('covid')) {
	echo '<meta name="robots" content="nonindex,nofollow">';
}
?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-129288316-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-129288316-1');
</script>

	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
	<meta name="google-site-verification" content="FN6xAjX1w6-lFogL3F6N1B78wBHe0GJIicqynZSqWz4" />
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php gravity_form_enqueue_scripts( 1, true ); ?>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div id="page" class="site">
<div class="stickynav">
	<div class="wrapper">
	<?php
			wp_nav_menu( array(
				'theme_location' => 'menu-1',
				'menu_id'        => 'primary-menu',
			) );
			?>
			<!--<a href="https://www.instagram.com/greggorymark/" target="_blank"><i class="fab fa-instagram"></i></a>-->
</div>
</div>
<div class="navspacer"></div>
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'mynameisgregg' ); ?></a>

	<header id="masthead" class="site-header ">
		<div class="wrapper">
		<div class="site-branding">
			<!--<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>-->
			
		</div><!-- .site-branding -->

		<!--<nav id="site-navigation" class="main-navigation">
			<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php esc_html_e( 'Primary Menu', 'mynameisgregg' ); ?></button>
			
		</nav><!-- #site-navigation -->
		</div>
	</header><!-- #masthead -->

	<div id="content" class="site-content">
