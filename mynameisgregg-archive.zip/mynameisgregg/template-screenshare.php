<?php
/**
* Template Name: Screenshare
**/

get_header();
?>
<style>
    body {
      background: #0098ff;
      display: flex;
      height: 100vh;
      margin: 0;
      align-items: center;
      justify-content: center;
      padding: 0 50px;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
    }
    video {
      background: white;
      background-image: url(https://www.kirupa.com/images/orange_logo_svg.svg);
      background-repeat: no-repeat;
      background-position: center;
      background-size: contain;
      max-width: calc(50% - 5%);
      margin: 0 5%;
      box-sizing: border-box;
      border-radius: 2px;
      padding: 0;
    }
    .copy {
      position: fixed;
      top: 25px;
      left: 50%;
      transform: translateX(-50%);
      font-size: 18px;
      color: white;
    }
  </style>
<section id="hello" class="parallax-div-00-bg">
<div class="parallax-div parallax-div-00" style="text-align: center;">
	
<div class="copy">Send your URL to a friend to start a video call</div>
  <video id="localVideo" autoplay muted></video>
  <video id="remoteVideo" autoplay></video>
    
	
   </div>
</section>


<?php
get_footer();
