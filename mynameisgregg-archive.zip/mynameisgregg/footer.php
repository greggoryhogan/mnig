<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package mynameisgregg
 */

?>
<?php if(!is_page('screenshare')) { ?>
<section id="contact">
	<div class="wrapper">
	
	<p class="subfact">Ready to get started?</p>
		<?php echo do_shortcode('[gravityform id="1" title="false" description="false" ajax="true"]'); ?>
	</div>
   
</section>
<?php } ?>
	</div><!-- #content -->

	<!--<footer id="colophon" class="site-footer">
		<div class="site-info wrapper">
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'mynameisgregg' ) ); ?>">
				<?php
				/* translators: %s: CMS name, i.e. WordPress. */
				printf( esc_html__( 'Proudly powered by %s', 'mynameisgregg' ), 'WordPress' );
				?>
			</a>
			<span class="sep"> | </span>
				<?php
				/* translators: 1: Theme name, 2: Theme author. */
				printf( esc_html__( 'Theme: %1$s by %2$s.', 'mynameisgregg' ), 'mynameisgregg', '<a href="http://underscores.me/">Underscores.me</a>' );
				?>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
