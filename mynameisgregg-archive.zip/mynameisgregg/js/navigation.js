/**
 * File navigation.js.
 *
 * Handles toggling the navigation menu for small screens and enables TAB key
 * navigation support for dropdown menus.
 */
(function($) {
$('.icons').slick({
		slidesToShow: 4,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 3000,
		pauseOnHover: false,
		responsive: [
			{
					breakpoint: 813, // tablet breakpoint
					settings: {
							slidesToShow: 1,
							slidesToScroll: 1
					}
			}
	]
	});
	$('.subfactul').slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		autoplay: false,
		autoplaySpeed: 3000,
		dots: false
	});


$('.subfactul .slick-prev,#whattodo .slick-prev').addClass('hidden');
	$('.subfactul').on('afterChange', function (event, slick, currentSlide) {
		
		if(currentSlide === 0) {
				$('.subfactul .slick-prev').addClass('hidden');
		}
		else {
				$('.subfactul .slick-prev').removeClass('hidden');
		}  
		if(currentSlide === 6) {
			$('.subfactul .slick-next').addClass('moveitonbuddy');
		}
});
$('#whattodo').on('afterChange', function (event, slick, currentSlide) {
		
	if(currentSlide === 0) {
			$('#whattodo .slick-prev').addClass('hidden');
	}
	else {
			$('#whattodo .slick-prev').removeClass('hidden');
	}  
});
$('#whattodo').slick({
	slidesToShow: 1,
	slidesToScroll: 1,
	autoplay: false,
	autoplaySpeed: 3000,
	dots: true,
	infinite: false
});
$('#enter').click(function(e) {
			var element = document.getElementById("welcome");

			element.scrollIntoView({behavior: "smooth"});
	  });
	  $('#continue').click(function(e) {
		var element = document.getElementById("continues");

		element.scrollIntoView({behavior: "smooth"});
  });
	  $(document).on('click','.moveitonbuddy',function(e){
	  	  e.preventDefault();
		  
		var element = document.getElementById("security");

		element.scrollIntoView({behavior: "smooth"});
		$('.moveitonbuddy').removeClass('moveitonbuddy');
  });
	  $('#hireme,.hireme,.slidetocontact a').click(function(e) {
		  e.preventDefault();
		  	var element = document.getElementById("contact");

			element.scrollIntoView({behavior: "smooth"});
		//}
	  });

	  

})( jQuery );