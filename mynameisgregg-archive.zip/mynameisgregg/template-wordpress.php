<?php
/**
* Template Name: WordPress
**/

get_header();
?>
<button id="hireme">Want to hire me?</button>
<section id="hello" class="parallax-div-00-bg mobilebg">
<div class="parallax-div parallax-div-00">
    <!-- <img src="assets/images/portfolio/surf-blog-media.jpg"> -->
    <div class="leading-statement statement-00">
	 <p> My Name is <span>Gregg</span></p>
	 <p>And I <span>Love</span> WordPress</p>
	
	 <p id="enter">V</p>
    </div>
	
   </div>
</section>

<section id="welcome" class="hidehideme">
	<div class="wrapper">
		<p class="fact">Why? Because it&rsquo;s awesome!</p>
		<p class="subfact">For obvious reasons, WordPress websites make up <strong><span style="color:#5aa9cf;">36%</span></strong> of the internet.</p>
		<div class="icons">
			<div class="awesomeicon"><i class="fas fa-dollar-sign"></i><span>It&rsquo;s<br>Free!<span></div>
			<div class="awesomeicon"><i class="fas fa-clock"></i><span>Installs in 5 minutes<span></div>
			<div class="awesomeicon"><i class="fas fa-box-open"></i><span>Friendly out of the box<span></div>
			<div class="awesomeicon"><i class="fab fa-google"></i><span>Google Loves It<span></div>
			<div class="awesomeicon"><i class="fas fa-plug"></i><span>Easily Extendable<span></div>
			<div class="awesomeicon"><i class="fas fa-lock-open"></i><span>Open Source<span></div>
		</div>

		<!--<br>In addition to the famous 5-minute installation, the wysiwyg interface makes creating and editing a breeze. The thousands of plugins available for download can expand on it&rsquo;s basic structure to infinite bounds! Worried about Google ranking? Search engines love WordPress. And the cost to install such a wondeful CMS? FREE! It&rsquo;s no wonder so many people choose WordPress day after day. </p>-->
	</div>
   
</section>

<section class="parallax-div-01 mobilebg" id="ohno">
    <!-- <img src="assets/images/portfolio/surf-blog-media.jpg"> -->
    <div class="leading-statement statement-00 lesstop">
	 <p> But it sure can be a <br>pain in the butt.</p>
    </div>
   
   
</section>

<section class="hidehideme">
	<div class="wrapper">
		<p class="fact">Let&rsquo;s follow the general life cycle of a WordPress website:<span class="mobileinstruction">(Swipe to go to the next slide)</span></p>
		<!--<p class="subfact">Ok, so that&rsquo;s a bit drastic, but let&rsquo;s follow the general life cycle of a WordPress website:</p>-->
		<ul class="subfactul">
		<li><i class="fas fa-bolt"></i><strong>1.</strong> Out of the box, WordPress is very secure and loads fairly fast, even on shared hosting.</li>
		<li><i class="fas fa-folder-plus"></i><strong>2.</strong> Rarely does anyone use the default theme bundled with WordPress, so they find a premium theme they purchase online.</li>
		<li><i class="fas fa-dolly"></i><strong>3.</strong> Lots of times, these themes requires additional plugins in order to function. 10 minutes into installation and there are already 4 or 5 plugins installed.</li>
		<li><i class="fas fa-puzzle-piece"></i><strong>4.</strong> The WordPress repository provides answers to the infinite number of desirables that are still on the list. The number of plugins installed starts to climb, as does the loading time.</li>
		<li><i class="fas fa-clock"></i><strong>5.</strong> Update Time! A new version of WordPress is released; hooray! Time to update the theme and all plugins so they stay in accordance with the latest security bases.</li>
		<li><i class="fas fa-file-invoice-dollar"></i><strong>6.</strong> Unfortunately, not all plugins are updated when a new version of WordPress is released. Additionally, the plugins bundled with a theme often require purchasing a license in order to be updated.</li>
		<li><i class="far fa-angry"></i><strong>7.</strong> Repeat this process a few times, and &ldquo;suddenly&rdquo; the website is loading awfully slow and the comments on blog posts are starting to fill with spam. It&rsquo;s time to seek some guidance.</li>
	</ul>

	
		
	</div>
   
</section>
<section id="security" class="mobilebg">
<div class="wrapper">
<p class="backdoor">Ultimately what happens to many WordPress websites over time is that the number of scripts and stylesheets from your theme and loaded plugins start to add up. Each of these are (generally) loaded on every page, taking up valuable bandwidth. <br><br>To add to that, even if you are updating WordPress with each release, you are still putting your website security in the hands of many third-party developers, who may not be as diligent with their updates as WordPress. This can open backdoors to spammers and hackers; who, once gain access, will stop at nothing to keep attacking your site.</p>
</div>
	</section>

<section class="hidehideme">
	<div class="wrapper">
	<p class="fact">So what do you do?</p>
		<p class="subfact">Aside from the obvious (hiring me), you have a few options<sup>*</sup></p>
	<ul class="whatfacts" id="whattodo">
		<li><span class="undies">Analyze your site&rsquo;s speed to find the weak points of your installation</span>
		Often times this includes optimizing images, combining scripts, and potentially employing a CDN, or Content Delivery Network.</li>
		<li><span class="undies">Perform a <a href="https://chrome.google.com/webstore/detail/lighthouse/blipmdconlkpinefehnmjammfjpmpbjk?hl=en" target="_blank">Lighthouse</a> audit on your website</span>
		Google&rsquo;s website auditing will compare your installation to the industry standard and give you feedback on what steps to take next.</li>
		<li><span class="undies">Perform a security audit on your current WordPress installation</span>
		Finding known loopholes and tightening security will stop potential hackers from ever reaching your installation.</li>
		<li><span class="undies">Subscribe to a monitoring software</span>
		Tools such as <a href="https://sucuri.net/" target="_blank">Sucuri</a> will monitor your website for any issues. They will alert you to any potential issues on your installation.</li>
		<li><span class="undies">But really, you should just hire me</span>
		Get in touch using the form at the bottom of the page if/when you&rsquo;re ready.</li>
	</ul>

			<p id="hearthedeal"><span class="ass">*</span>Here&rsquo;s the deal: You can do this. I believe in you. I&rsquo;m just here to make your life easier.</p>
	<!--<div class="hireme">Ready to Hire me?</div>-->
	</div>
   
</section>

<section id="rant" class="mobilebg">
	<div class="wrapper">
		<p class="fact">Rant Over.</p>
		<p class="subfact">All I really want is a better internet, is that so much to ask? Let&rsquo;s work together to make browsing a faster and safer experience.
			<img src="<?php echo get_bloginfo('template_url'); ?>/images/sign2.png" />
	</div>
</section>

<?php
get_footer();
