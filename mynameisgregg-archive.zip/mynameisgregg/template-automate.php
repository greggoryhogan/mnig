<?php
/**
* Template Name: Automation
**/

get_header();
?>
<button id="hireme">Want to hire me?</button>
<section id="hello" class="parallax-div-00-bg">
<div class="parallax-div parallax-div-00">
    <!-- <img src="assets/images/portfolio/surf-blog-media.jpg"> -->
    <div class="leading-statement statement-00">
	 <p><span>Gregg</span> Hogan</p>
	 <p>Web Consultant <span>+ Developer</span></p>
	
	 <p id="enter">V</p>
    </div>
	
   </div>
</section>

<!--<section id="welcome">
	<div class="wrapper">
		<p class="fact" style="margin-bottom: 0px;">&ldquo;I can make your business run smoother.&rdquo;</p>
		<p class="subfact">-Me</p>

		<p class="fact" style="margin-bottom: 0px;">&ldquo;I highly doubt that...&rdquo;</p>
		<p class="subfact">-You</p>

	</div>
   
</section>-->
<section>
	<div class="wrapper">
	<p class="fact">Many companies under utilize the power of the web and automation.</p>
	<p class="subfact">Why? Probably because they haven&rsquo;t spent the last ten years coding automated tasks.</p><p class="subfact">How do you collect customer information? How do you communicate with your employees? How much time did you spend on the last customer? I&rsquo;m willing to bet you spend a little too much time on these details, which eats up more time doing your job.</p>
	</div>
   
</section>


<section id="research">
	<div class="wrapper">
	<p class="fact" style="color:#fff;">This is where I come in.</p>
	</div>
</section>
<!--Many companies under utilize the power of the web and automation.<br>Why? Probably because they haven&rsquo;t spent the last ten years coding automated tasks.-->
<section>
	<div class="wrapper">
	<p class="fact">Let&rsquo;s give your business a tech facelift.</p><p class="subfact">By auditing your business&rsquo;s daily tasks, we can find the repetitive or overcomplicated actions where you lose time. From there we can discuss solutions to your specific problem. Whether your business is 50 years old or 5, technology moves at a break-neck speed, and new solutions are arising daily.</p>
	</div>
   
</section>

<section id="rocket">
	<div class="wrapper">
		<p class="fact">Ready to get moving?</p>
		<p class="subfact">Together we can make your business run at rocket speed, so you can spend more time focusing on the customer and less time worrying about the details.
			<img src="<?php echo get_bloginfo('template_url'); ?>/images/sign2.png" />
	</div>
</section>

<?php
get_footer();
