<?php
/**
 * mynameisgregg functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package mynameisgregg
 */

if ( ! function_exists( 'mynameisgregg_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function mynameisgregg_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on mynameisgregg, use a find and replace
		 * to change 'mynameisgregg' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'mynameisgregg', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'mynameisgregg' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );
	}
endif;
add_action( 'after_setup_theme', 'mynameisgregg_setup' );

/**
 * Enqueue scripts and styles.
 */
function mynameisgregg_scripts() {
	wp_enqueue_style( 'mynameisgregg-style', get_stylesheet_uri() );
	wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/css/all.css');
    wp_enqueue_script( 'mynameisgregg-navigation', get_template_directory_uri() . '/js/navigation.js', array('jquery'), '20151215', true );

	/*wp_enqueue_script( 'mynameisgregg-scaledrone', 'https://cdn.scaledrone.com/scaledrone.min.js', array('jquery'), '20151215', true );
  	wp_enqueue_script( 'mynameisgregg-screenshare', get_template_directory_uri() . '/js/share.js', array('jquery'), '20151215', true );*/
}
add_action( 'wp_enqueue_scripts', 'mynameisgregg_scripts' );

function register_slick() {
	wp_enqueue_script( 'slick', get_template_directory_uri() . '/js/slick.js', array('jquery'), '20151215' );
	/*if ( is_home() || is_front_page() ) {
		wp_enqueue_script( 'slick', get_template_directory_uri() . '/js/slick.js', array('jquery'), '20151215' );
	}*/
  }
  add_action( 'wp_enqueue_scripts', 'register_slick' );

  remove_action('wp_head', 'wp_generator');
  
function gregg() {
	echo '<img src="'.get_bloginfo('template_url').'/images/gregg.png" class="gregg" />';
}
function testimonials() {
	$testimonials = '<div class="testimonials">';

	$testimonials .= '<div class="content-column one_half"><i class="fas fa-quote-left"></i><p>Gregg was exceptional.  He completed the work timely and to my specifications.  He listened well and took the time to understand my requirements.  I would not hesitate to use him in the future.</p></div>';//<span>John Stack, 3 Big Heads</span>
	$testimonials .=  '<div class="content-column one_half last_column"><i class="fas fa-quote-left"></i><p>Gregg has been once again very fast in both his work and communication. This is the second time we have used him, and we will again!</p></div>';	

		$testimonials .= '</div>';

	return $testimonials;
}
add_shortcode('testimonials', 'testimonials');

function clients() {
	$clients = '<div class="clients">';

	$clients .= '<a href="https://henryusa.com" target="_blank" rel="nofollow"><img src="https://mynameisgregg.com/wp-content/uploads/2018/11/henry.jpg" /></a>';

	$clients .= '<a href="http://playtime.pem.org/" target="_blank" rel="nofollow"><img src="https://mynameisgregg.com/wp-content/uploads/2018/11/playtime-1.jpg" /></a>';

	$clients .= '<a href="https://projectmepro.com/" target="_blank" rel="nofollow"><img src="https://mynameisgregg.com/wp-content/uploads/2018/11/pmp-1.jpg" /></a>';

	$clients .= '<a href="http://www.guildhumanservices.org/" target="_blank" rel="nofollow"><img src="https://mynameisgregg.com/wp-content/uploads/2018/11/guild-1.jpg" /></a>';

	$clients .= '<a href="http://thesuperhelpfulwebsite.com/" target="_blank" rel="nofollow"><img src="https://mynameisgregg.com/wp-content/uploads/2018/11/super.jpg" /></a>';

	$clients .= '<a href="https://www.margebar.com/" target="_blank" rel="nofollow"><img src="https://mynameisgregg.com/wp-content/uploads/2018/11/marge-2.jpg" /></a>';

	$clients .= '<a href="https://southshorerealtors.com/" target="_blank" rel="nofollow"><img src="https://mynameisgregg.com/wp-content/uploads/2018/11/ssr.jpg" /></a>';
	
	

	

	$clients .= '</div>';

	return $clients;
}
add_shortcode('clients', 'clients');